# OFFBALL

Proyecto de Big Data e Inteligencia Artificial aplicado al análisis y scouting de jugadores de fútbol.

El repositorio se irá completando durante el desarrollo.

## Estructura

- `big_data/`: Hadoop, HDFS y procesamiento.
- `data/`: datos originales, sucios y limpios. No subir datasets grandes o con restricciones.
- `notebooks/`: análisis y experimentos de machine learning.
- `models/`: modelos de clustering y regresión.
- `api/`: API e interfaz.
- `mlflow/`: seguimiento de experimentos.
- `docs/`: informe principal, planificación, documentación legal y evidencias.
